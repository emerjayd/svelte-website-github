import{a as t}from"../chunks/entry.CWrrCHU_.js";export{t as start};
